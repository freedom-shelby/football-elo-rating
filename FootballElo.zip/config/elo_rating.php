<?php

return [
    'rating_column_name' => 'rating',
    'games_column_name' => 'games',
];
