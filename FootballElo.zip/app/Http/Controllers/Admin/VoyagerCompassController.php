<?php

namespace App\Http\Controllers\Admin;

use TCG\Voyager\Http\Controllers\VoyagerCompassController as BaseVoyagerCompassController;

class VoyagerCompassController extends BaseVoyagerCompassController
{
    //
}
